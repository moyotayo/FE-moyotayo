// Stage.jsx — fixed 1440×1024 canvas that scales to fit the viewport.
// Centers itself, letterboxes on neutral grey, exposes `--sp-scale`.

const Stage = ({ children }) => {
  const [scale, setScale] = React.useState(1);
  React.useEffect(() => {
    const fit = () => {
      const s = Math.min(window.innerWidth / 1440, window.innerHeight / 1024);
      setScale(s);
    };
    fit();
    window.addEventListener('resize', fit);
    return () => window.removeEventListener('resize', fit);
  }, []);

  return (
    <div style={{
      position: 'fixed', inset: 0,
      background: '#E9EEF2',
      display: 'flex', alignItems: 'center', justifyContent: 'center',
      overflow: 'hidden',
    }}>
      <div style={{
        width: 1440, height: 1024,
        flexShrink: 0,
        transform: `scale(${scale})`,
        transformOrigin: 'center',
        position: 'relative',
        background: '#FFFFFF',
        overflow: 'hidden',
        boxShadow: '0 20px 80px rgba(0,0,0,.15)',
      }}>
        {children}
      </div>
    </div>
  );
};

window.Stage = Stage;
