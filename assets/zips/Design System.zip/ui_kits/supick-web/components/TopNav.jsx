// TopNav.jsx — fixed top nav. Flex with two flexible spacers so visible
// whitespace between (logo ↔ items) and (items ↔ 마이페이지) stays equal
// regardless of how wide the logo or right-side link happen to be.

const TopNav = ({ activeId, onNavigate }) => {
  const items = [
    { id: 'home',      label: '홈' },
    { id: 'recommend', label: '시간표 추천' },
    { id: 'reviews',   label: '강의 평가' },
  ];
  return (
    <div style={{
      position: 'absolute',
      top: 28, left: 60, right: 60,
      height: 60,
      display: 'flex',
      alignItems: 'center',
      zIndex: 20,
    }}>
      {/* Logo */}
      <div
        onClick={() => onNavigate('home')}
        style={{
          display: 'flex', alignItems: 'center', gap: 6,
          fontFamily: 'Pretendard Variable, Pretendard, sans-serif',
          fontWeight: 900, fontSize: 48,
          letterSpacing: '-1.2px',
          cursor: 'pointer', lineHeight: 1,
        }}
      >
        <span style={{ color: '#1A5BA8', marginRight: 1 }}>Su</span><span style={{ color: '#000' }}>Pick</span>
        <Sparkle color="#1E8A52" size={26} />
      </div>

      <div style={{ flex: 1 }} />

      <div style={{ display: 'flex', alignItems: 'center', gap: 40 }}>
        {items.map(item => (
          <Button
            key={item.id}
            variant={activeId === item.id ? 'ghost-active' : 'ghost'}
            onClick={() => onNavigate(item.id)}
          >
            {item.label}
          </Button>
        ))}
      </div>

      <div style={{ flex: 1 }} />

      <Button
        variant={activeId === 'mypage' ? 'ghost-active' : 'ghost'}
        onClick={() => onNavigate('mypage')}
      >
        마이페이지
      </Button>
    </div>
  );
};

window.TopNav = TopNav;
