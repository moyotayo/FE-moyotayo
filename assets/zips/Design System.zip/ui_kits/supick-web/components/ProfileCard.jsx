// ProfileCard.jsx — mascot avatar + name + dept + status pill.

const ProfileCard = ({ user }) => (
  <div style={{
    width: 460,
    background: '#FFF',
    borderRadius: 12,
    border: '1.5px solid #2A99E5',
    boxShadow: '0 4px 4px rgba(0,0,0,0.18)',
    padding: 28,
    display: 'flex', flexDirection: 'row', gap: 22, alignItems: 'center',
  }}>
    <div style={{
      width: 170, height: 170,
      borderRadius: '50%',
      background: '#D9D9D9',
      overflow: 'hidden',
      flexShrink: 0,
    }}>
      <img src={user.avatar} alt="" style={{
        width: '100%', height: '100%', objectFit: 'cover',
      }} />
    </div>
    <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
      <div style={{
        fontFamily: 'Jua, sans-serif',
        fontSize: 32, color: '#000', lineHeight: 1,
      }}>{user.name}</div>
      <div style={{
        fontFamily: 'Pretendard Variable, Pretendard, sans-serif',
        fontWeight: 500,
        fontSize: 14, color: '#4B4B4B',
        lineHeight: 1.5,
        letterSpacing: '-.005em',
      }}>
        {user.dept} · {user.cohort} · {user.status}
      </div>
      <div style={{ marginTop: 6 }}>
        <CategoryBadge category="jeonhaek" label={user.badge} size="md" />
      </div>
    </div>
  </div>
);

window.ProfileCard = ProfileCard;
