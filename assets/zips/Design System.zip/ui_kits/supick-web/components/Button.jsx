// Button.jsx — three button styles in one component:
//   variant="pill"       glass capsule, primary CTA
//   variant="outline"    blue-outlined white pill, secondary
//   variant="rect"       rounded-rectangle, inline action
//   variant="ghost"      transparent text-only nav item

const Button = ({ variant = 'pill', children, onClick, glow = false, color, style }) => {
  const base = {
    fontFamily: 'Jua, sans-serif',
    fontSize: 20,
    lineHeight: 1,
    cursor: 'pointer',
    userSelect: 'none',
    border: 0,
    display: 'inline-flex',
    alignItems: 'center',
    justifyContent: 'center',
    whiteSpace: 'nowrap',
    transition: 'transform 120ms ease-out, box-shadow 180ms ease-out',
  };
  const variants = {
    pill: {
      height: 56, padding: '0 36px',
      borderRadius: 20,
      background: 'rgba(255,255,255,0.10)',
      boxShadow: '0 0 20px rgba(22,86,132,0.90)',
      color: '#1A5BA8',
      letterSpacing: '0.4em',
      paddingRight: 36 - 7,
    },
    outline: {
      height: 44, padding: '0 24px',
      borderRadius: 100,
      background: '#FFFFFF',
      border: '1px solid #1A5BA8',
      color: '#1A5BA8',
      fontSize: 18,
    },
    rect: {
      height: 47, padding: '0 20px',
      borderRadius: 10,
      background: 'rgba(96,169,255,0.18)',
      border: '1px solid #2A99E5',
      boxShadow: '0 4px 4px rgba(26,91,168,0.85)',
      color: '#000',
      fontSize: 20,
    },
    ghost: {
      height: 50, padding: '0 26px',
      borderRadius: 20,
      background: 'transparent',
      color: '#000',
      fontSize: 18,
    },
    'ghost-active': {
      height: 50, padding: '0 26px',
      borderRadius: 20,
      background: 'rgba(255,255,255,0.10)',
      boxShadow: '0 0 20px rgba(22,86,132,0.90)',
      color: '#000',
      fontSize: 18,
    },
  };
  return (
    <button
      onClick={onClick}
      style={{ ...base, ...variants[variant], ...(color ? { color } : {}), ...style }}
      onMouseDown={(e) => { e.currentTarget.style.transform = 'scale(0.96)'; }}
      onMouseUp={(e)   => { e.currentTarget.style.transform = 'scale(1)'; }}
      onMouseLeave={(e)=> { e.currentTarget.style.transform = 'scale(1)'; }}
    >
      {children}
    </button>
  );
};

window.Button = Button;
