// CategoryBadge.jsx — the small outline pill in a category colour.

const CategoryBadge = ({ category, label, size = 'md' }) => {
  const cat = CATEGORIES[category] || { color: '#000', label: label || '?' };
  const heights = { sm: 20, md: 24, lg: 28 };
  const fonts   = { sm: 13, md: 16, lg: 18 };
  return (
    <span style={{
      display: 'inline-flex',
      alignItems: 'center',
      justifyContent: 'center',
      borderRadius: 15,
      border: `1px solid ${cat.color}`,
      color: cat.color,
      background: 'rgba(255,255,255,0.6)',
      padding: `0 10px`,
      height: heights[size],
      fontFamily: 'Jua, sans-serif',
      fontSize: fonts[size],
      lineHeight: 1,
      whiteSpace: 'nowrap',
    }}>
      {label || cat.label}
    </span>
  );
};

window.CategoryBadge = CategoryBadge;
