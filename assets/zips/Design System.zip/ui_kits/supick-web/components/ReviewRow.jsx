// ReviewRow.jsx — single review with stars, hashtag tags, and heart count.

const Heart = ({ size = 18 }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="#E14545">
    <path d="M12 21s-7-4.35-7-10a4.5 4.5 0 0 1 8-2.83A4.5 4.5 0 0 1 19 11c0 5.65-7 10-7 10z" />
  </svg>
);

const ReviewRow = ({ review }) => (
  <div style={{
    padding: '16px 18px',
    borderBottom: '1px solid rgba(0,0,0,.07)',
    display: 'flex', flexDirection: 'column', gap: 8,
  }}>
    <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
      <div style={{
        fontFamily: 'Pretendard Variable, sans-serif',
        fontWeight: 700, fontSize: 16, color: '#000',
      }}>{review.title} ({review.professor})</div>
      <div style={{ color: '#FFC940', letterSpacing: 1, fontSize: 16 }}>
        {Array.from({ length: 5 }).map((_, i) => (
          <span key={i} style={{ color: i < review.stars ? '#FFC940' : '#D9D9D9' }}>★</span>
        ))}
      </div>
      <div style={{
        fontFamily: 'Pretendard Variable, sans-serif', fontWeight: 500,
        fontSize: 14, color: '#000',
      }}>{review.stars}/{review.total}  ({review.ratings})</div>
      <div style={{ flex: 1 }} />
      <div style={{
        display: 'flex', alignItems: 'center', gap: 4,
        fontFamily: 'Pretendard Variable, sans-serif', fontWeight: 700,
        fontSize: 16, color: '#E14545',
      }}>
        <Heart /> {review.likes}
      </div>
    </div>
    <div style={{
      display: 'flex', flexWrap: 'wrap', gap: 12,
      fontFamily: 'Pretendard Variable, sans-serif',
      fontSize: 14, color: '#4B4B4B',
    }}>
      {review.tags.map(t => <span key={t}>{t}</span>)}
    </div>
  </div>
);

window.ReviewRow = ReviewRow;
