// MyPage.jsx — profile, credits, link buttons, semester selector, signoff.

const MyPage = ({ user, courses }) => {
  const [semester, setSemester] = React.useState('25년 1학기');
  const [showPicker, setShowPicker] = React.useState(false);

  return (
    <div style={{ position: 'absolute', inset: 0, background: '#FFF' }}>
      <BgCircles />

      {/* Page title */}
      <div style={{
        position: 'absolute', top: 130, left: 80,
        fontFamily: 'Jua, sans-serif',
        fontSize: 40, color: '#000',
      }}>마이페이지</div>

      {/* Left: timetable with semester switcher */}
      <div style={{ position: 'absolute', top: 220, left: 80 }}>
        <div style={{
          display: 'flex', alignItems: 'center', gap: 16,
          marginBottom: 18,
        }}>
          <div style={{
            fontFamily: 'Jua, sans-serif',
            fontSize: 28, color: '#000',
          }}>2026년 / 2학년 1학기 시간표</div>
          <div style={{ position: 'relative', marginLeft: 80 }}>
            <button
              onClick={() => setShowPicker(v => !v)}
              style={{
                height: 38, padding: '0 22px',
                borderRadius: 10,
                background: 'rgba(81,161,255,.47)',
                border: '1px solid rgba(26,91,168,.7)',
                boxShadow: '0 4px 3px rgba(26,91,168,.4)',
                fontFamily: 'Jua, sans-serif', fontSize: 22,
                color: '#000', cursor: 'pointer',
              }}>&lt;  선택  &gt;</button>
            {showPicker && (
              <div style={{
                position: 'absolute', top: 50, right: 0,
                background: 'linear-gradient(180deg, #FFFFFF 0%, #C5DFF0 100%)',
                borderRadius: 16,
                border: '1px solid #2A99E5',
                padding: 14,
                display: 'flex', flexDirection: 'column', gap: 10,
                width: 200, zIndex: 5,
                boxShadow: '0 12px 30px rgba(0,0,0,.15)',
              }}>
                {['26년 1학기', '25년 2학기', '25년 1학기'].map(s => (
                  <FilterChip key={s} label={s} selected={s === semester}
                              onClick={() => { setSemester(s); setShowPicker(false); }} />
                ))}
              </div>
            )}
          </div>
        </div>
        <Timetable courses={courses} height={720} />
      </div>

      {/* Right: profile column */}
      <div style={{
        position: 'absolute',
        right: 70, top: 220,
        display: 'flex', flexDirection: 'column', gap: 18,
      }}>
        <ProfileCard user={user} />

        <div style={{
          height: 70,
          background: '#FFF',
          border: '1.5px solid #2A99E5',
          borderRadius: 10,
          boxShadow: '0 4px 4px rgba(26,91,168,.5)',
          display: 'flex', alignItems: 'center',
          padding: '0 22px', justifyContent: 'space-between',
        }}>
          <span style={{
            fontFamily: 'Pretendard Variable, sans-serif',
            fontSize: 22, color: '#000',
          }}>수강 학점 : {user.credits}학점</span>
          <span style={{
            fontFamily: 'Pretendard Variable, sans-serif',
            fontSize: 14, color: '#757070',
          }}>공강 {user.freePeriods}</span>
        </div>

        <div style={{ display: 'flex', gap: 14 }}>
          <Button variant="rect" style={{ flex: 1 }}>문의하기</Button>
          <Button variant="rect" style={{ flex: 1 }}>내 강의평</Button>
        </div>
        <Button variant="rect">내 정보</Button>

        <div style={{
          height: 1, background: '#2A99E5', marginTop: 10,
        }} />

        <div style={{
          display: 'flex', alignItems: 'center', gap: 8,
          fontFamily: 'Jua, sans-serif',
          fontSize: 26, color: '#000', justifyContent: 'center',
        }}>
          ☀️
          <span><span style={{ color: '#1A5BA8' }}>{user.name}님</span> 민첩한 하루되세요!</span>
          🌻🌹
        </div>
      </div>

      {/* Bottom-right pill row */}
      <div style={{
        position: 'absolute', right: 80, bottom: 60,
        display: 'flex', gap: 22,
      }}>
        <button style={{
          height: 48, padding: '0 28px',
          borderRadius: 100, background: '#FFF',
          border: 0, boxShadow: '0 0 20px rgba(255,0,0,.55)',
          fontFamily: 'Jua, sans-serif', fontSize: 20,
          cursor: 'pointer',
        }}>로그아웃</button>
        <button style={{
          height: 48, padding: '0 28px',
          borderRadius: 100, background: '#FFF',
          border: 0, boxShadow: '0 0 20px rgba(0,0,0,.55)',
          fontFamily: 'Jua, sans-serif', fontSize: 20,
          cursor: 'pointer',
        }}>회원 탈퇴</button>
      </div>
    </div>
  );
};

window.MyPage = MyPage;
