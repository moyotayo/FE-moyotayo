# SuPick — Web UI kit

A click-through hi-fi recreation of the SuPick web app, written in inline JSX + React. There is **no real backend or routing** — every "navigation" is just `useState`. The kit exists to make new mockups faster: copy a screen, copy a component, edit copy, you're done.

## Run

Open `index.html`. It scales a fixed 1440×1024 canvas to fit any viewport, so it looks right on a laptop or in a screenshot.

## Surfaces

| Screen | File | What it does |
|---|---|---|
| Welcome | `screens/Welcome.jsx` | Hero wordmark + launch pill + 시작하기 button. Click 시작하기 → Home. |
| 홈 | `screens/Home.jsx` | Three stat chips, sticky-note timetable, course list with sparkles + category badges. |
| 시간표 추천 | `screens/Recommend.jsx` | Search field, filter chip row, course results, PickList side-panel with stepper buttons. |
| 강의 평가 | `screens/Reviews.jsx` | Reviewable courses list (stars + hashtags + heart counts) + "수강 과목 평가하기" composer. |
| 마이페이지 | `screens/MyPage.jsx` | Profile card, credit total, 4 link buttons, semester selector, mascot signoff. |

## Components

```
components/
  TopNav.jsx          fixed top navigation; takes activeId + onNavigate
  Sparkle.jsx         the 4-point category-coloured star with glow
  CategoryBadge.jsx   small outline-pill in a category color
  CourseRow.jsx       sparkle + title + meta + badge, used in lists
  CourseRowAction.jsx variant with + / - stepper at the right (recommend)
  Timetable.jsx       calendar card with sticky-note course blocks
  StatChip.jsx        red/green/cyan big-number dashboard chip
  PickList.jsx        side cart panel for recommend
  SearchInput.jsx     pill input + filter button pair
  FilterChip.jsx      pale-blue chip with selected (green ✓) variant
  Button.jsx          glass-glow pill, outlined pill, rounded rectangle
  Mascot.jsx          fixed bottom-right mascot, optional speech bubble
  Stage.jsx           1440×1024 canvas that scales to viewport + page wash
  BgCircles.jsx       two off-canvas circles (sky blue + green wedge)
  ProfileCard.jsx     mascot avatar + name + dept + status pill
  ReviewRow.jsx       single review with stars/hashtags/heart
  data.js             a few sample courses + reviews to populate screens
```

## Adding a course

`data.js` exports an array of courses with the shape:

```js
{
  id: 'kt-net',
  title: '컴퓨터네트워크',
  professor: '김아람',
  location: 'IT대학 306호',
  day: '월', start: '11:30', end: '13:20',
  category: 'jeonhaek',       // see CategoryBadge for the seven keys
  credits: 3,
  area: '5영역',
}
```

Add a row, refresh — it appears in every list and on the timetable.

## What this kit is not

- It is **not** production code. Components use inline styles + CSS vars.
- There is **no router** — `App.jsx` keeps the current screen in `useState`.
- There is **no real data** — `data.js` ships ~8 sample courses and 2 reviews.
- It does **not** cover the carpool-era GUI-v0.1 designs (those are out of scope).

## Image credits

The mascot art (`assets/mascot-wizard-*.png`) and the PickList basket were exported from the SuPick Figma. We did not redraw them.
