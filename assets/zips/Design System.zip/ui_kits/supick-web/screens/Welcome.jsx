// Welcome.jsx — splash screen.

const Welcome = ({ onStart }) => (
  <div style={{ position: 'absolute', inset: 0, background: '#FFFFFF' }}>
    <BgCircles />

    <div style={{
      position: 'absolute',
      left: 0, right: 0, top: 280,
      display: 'flex', flexDirection: 'column',
      alignItems: 'center', gap: 36,
    }}>
      {/* launch badge */}
      <div style={{
        height: 44, padding: '0 30px',
        borderRadius: 100,
        background: '#FFF',
        border: '1px solid #1A5BA8',
        display: 'flex', alignItems: 'center', gap: 10,
        fontFamily: 'Pretendard Variable, sans-serif', fontSize: 22,
        color: '#1A5BA8',
      }}>
        <span style={{
          width: 8, height: 8, borderRadius: '50%',
          background: '#1E8A52',
          boxShadow: '0 0 8px rgba(30,138,82,.9)',
        }} />
        2026년 2학기 서비스 오픈
      </div>

      {/* Wordmark with backing circle */}
      <div style={{ position: 'relative', display: 'flex', alignItems: 'center', gap: 18 }}>
        <div style={{
          position: 'absolute',
          left: -22, top: 12,
          width: 200, height: 200,
          borderRadius: '50%',
          background: 'rgba(197,223,240,0.6)',
        }} />
        <div style={{
          position: 'relative',
          fontFamily: 'Pretendard Variable, sans-serif',
          fontWeight: 900, fontSize: 128,
          letterSpacing: '-4px',
          lineHeight: 1,
        }}>
          <span style={{ color: '#1A5BA8', marginRight: 3 }}>Su</span><span style={{ color: '#000' }}>Pick</span>
        </div>
        <Sparkle color="#1E8A52" size={60} glowAlpha={0.6} />
      </div>

      <div style={{
        fontFamily: 'Jua, sans-serif',
        fontSize: 28, color: '#1E8A52',
        letterSpacing: '0.04em',
        marginTop: -10,
      }}>수원대 강의 탐색 서비스</div>

      <div style={{ marginTop: 26 }}>
        <Button variant="pill" onClick={onStart}>시작하기</Button>
      </div>
    </div>

    <Mascot pose="standing" size={520} position="bottomRight" />
  </div>
);

window.Welcome = Welcome;
