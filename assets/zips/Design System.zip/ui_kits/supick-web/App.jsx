// App.jsx — root component. Holds active screen + picklist state.

const App = () => {
  const [screen, setScreen] = React.useState('welcome');
  const [picklist, setPicklist] = React.useState([]);
  const data = window.SUPICK_DATA;

  return (
    <Stage>
      {screen !== 'welcome' && (
        <TopNav activeId={screen} onNavigate={setScreen} />
      )}

      {screen === 'welcome'   && <Welcome onStart={() => setScreen('home')} />}
      {screen === 'home'      && <Home user={data.user} courses={data.courses} />}
      {screen === 'recommend' && (
        <Recommend
          allCourses={data.courses}
          picklist={picklist}
          onPickListChange={setPicklist}
        />
      )}
      {screen === 'reviews'   && <Reviews reviews={data.reviews} courses={data.courses} />}
      {screen === 'mypage'    && <MyPage user={data.user} courses={data.courses} />}

      {/* Slide-label for the host to track which screen we're on */}
      <div data-screen-label={screen} style={{ display: 'none' }} />
    </Stage>
  );
};

ReactDOM.createRoot(document.getElementById('root')).render(<App />);
