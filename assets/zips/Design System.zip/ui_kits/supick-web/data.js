// data.js — sample courses + reviews used to populate every screen.
// All seven category keys appear so the UI kit exercises every color path.

window.SUPICK_DATA = {
  courses: [
    { id: 'mw',  title: '악성코드분석',          professor: '김대엽', location: '수원역4번출구', day: '월', start: '9:30',  end: '12:20', category: 'jeonseon', credits: 3, area: '전선' },
    { id: 'ca',  title: '중앙아시아의이해(이러닝)', professor: '박승찬', location: '온라인',     day: '월', start: '9:30',  end: '11:20', category: 'gyoyang',  credits: 2, area: '교양' },
    { id: 'net', title: '컴퓨터네트워크',         professor: '김아람', location: 'IT대학 306호', day: '화', start: '12:30', end: '14:20', category: 'jeonhaek', credits: 3, area: '전핵' },
    { id: 'sem', title: '전공진로세미나1',         professor: '주호연', location: 'IT대학 502호', day: '수', start: '12:30', end: '13:20', category: 'jeonchwi', credits: 1, area: '전취' },
    { id: 'esl', title: 'AI활용ESL1',            professor: '자스민', location: '인문101호',   day: '목', start: '12:30', end: '14:20', category: 'gigyo',    credits: 2, area: '기교' },
    { id: 'thn', title: '학문과 사고',             professor: '최재령', location: '인문205호',   day: '월', start: '13:30', end: '15:20', category: 'junghaek', credits: 2, area: '중핵' },
    { id: 'lif', title: '인성과 삶의 가치',          professor: '이소민', location: '온라인',     day: '금', start: '15:30', end: '17:20', category: 'sogyo',    credits: 2, area: '소교' },
    { id: 'web', title: '웹프로그래밍',            professor: '전상훈', location: 'IT대학 306호', day: '금', start: '11:30', end: '15:20', category: 'jeonhaek', credits: 3, area: '전핵' },
  ],

  reviews: [
    {
      id: 'r1',
      title: '인성과 삶의 가치',
      professor: '이소민',
      stars: 4, total: 5, ratings: 10,
      tags: ['#과제_적음', '#문제풀이_과제', '#전자출결', '#온라인시험', '#조모임_없음', '#P/F'],
      likes: 1,
      category: 'sogyo',
    },
    {
      id: 'r2',
      title: '식문화의 형성과 세계화',
      professor: '오사다 사치코',
      stars: 5, total: 5, ratings: 13,
      tags: ['#과제_보통', '#보고서_및_조사_과제', '#자필서명', '#지필고사', '#조모임_없음', '#ABCDF'],
      likes: 2,
      category: 'gyoyang',
    },
  ],

  user: {
    name: '이하은',
    dept: '정보보호학과',
    cohort: '17학번',
    status: '재학생',
    badge: '적폐',
    avatar: '../../assets/mascot-wizard-standing.png',
    credits: 21,
    freePeriods: 4,
  },
};
