// SearchInput.jsx — pill input + optional filter button at the right.

const SearchInput = ({ placeholder = '강의명 또는 교수명을 입력해주세요', value, onChange, withFilter, onFilter, filterActive }) => (
  <div style={{ display: 'flex', gap: 14, width: '100%' }}>
    <div style={{
      flex: 1, height: 56,
      background: '#FFF',
      borderRadius: 100,
      border: '1.5px solid #2A99E5',
      boxShadow: '0 4px 4px rgba(0,0,0,0.10)',
      display: 'flex', alignItems: 'center',
      padding: '0 26px',
      gap: 14,
    }}>
      <input
        value={value || ''}
        onChange={e => onChange && onChange(e.target.value)}
        placeholder={placeholder}
        style={{
          flex: 1, border: 0, outline: 'none', background: 'transparent',
          fontFamily: 'Pretendard Variable, sans-serif',
          fontSize: 18, color: '#000',
        }}
      />
      <svg width="22" height="22" viewBox="0 0 24 24" fill="none"
           stroke="#2A99E5" strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round">
        <circle cx="11" cy="11" r="7"/><line x1="20" y1="20" x2="16.65" y2="16.65"/>
      </svg>
    </div>
    {withFilter && (
      <button onClick={onFilter} style={{
        width: 60, height: 56,
        borderRadius: 14,
        background: filterActive ? '#E8F5FF' : '#FFF',
        border: '1.5px solid #2A99E5',
        boxShadow: '0 4px 4px rgba(0,0,0,0.10)',
        color: '#2A99E5',
        cursor: 'pointer',
        display: 'flex', alignItems: 'center', justifyContent: 'center',
      }}>
        <svg width="22" height="22" viewBox="0 0 24 24" fill="none"
             stroke="currentColor" strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round">
          <polygon points="22 3 2 3 10 12.46 10 19 14 21 14 12.46 22 3"/>
        </svg>
      </button>
    )}
  </div>
);

window.SearchInput = SearchInput;
