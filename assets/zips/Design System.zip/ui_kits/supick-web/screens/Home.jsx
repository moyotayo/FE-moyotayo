// Home.jsx — dashboard. Three stat chips up top, timetable on left,
// course list on the right.

const Home = ({ user, courses }) => (
  <div style={{ position: 'absolute', inset: 0, background: '#FFF' }}>
    <BgCircles />

    <div style={{ position: 'absolute', top: 138, left: 70, right: 70, display: 'flex', gap: 30 }}>
      {/* Left column */}
      <div style={{ display: 'flex', flexDirection: 'column', gap: 22 }}>
        <div style={{ display: 'flex', gap: 20 }}>
          <StatChip tone="red"   value={courses.length} label="수강 과목 수" />
          <StatChip tone="green" value={courses.reduce((s,c)=>s+c.credits,0)} label="신청 학점" />
          <StatChip tone="cyan"  value={new Set(courses.map(c=>c.day)).size} label="주간 수업 일 수" />
        </div>
        <Timetable courses={courses} height={690} />
      </div>

      {/* Right column — course list */}
      <div style={{
        width: 480, height: 800,
        borderRadius: 14,
        border: '1px solid #C5DFF0',
        background: 'rgba(255,255,255,0.5)',
        boxShadow: '0 4px 18px rgba(0,0,0,.06)',
        padding: '22px 18px',
        overflowY: 'auto',
        display: 'flex', flexDirection: 'column', gap: 12,
      }}>
        {courses.map(c => <CourseRow key={c.id} course={c} />)}
      </div>
    </div>
  </div>
);

window.Home = Home;
