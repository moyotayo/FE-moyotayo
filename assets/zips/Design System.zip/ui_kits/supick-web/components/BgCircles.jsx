// BgCircles.jsx — the signature off-canvas decoration.
// Two big circles bleed in from corners; an optional grey overlay
// dims the canvas when a modal is open.

const BgCircles = ({ topLeft = true, bottomRight = true, dim = false }) => (
  <React.Fragment>
    {topLeft && (
      <div style={{
        position: 'absolute',
        left: -140, top: -180,
        width: 740, height: 720,
        borderRadius: '50%',
        background: 'rgba(197,223,240,0.55)',
        filter: 'blur(0.2px)',
        pointerEvents: 'none',
      }} />
    )}
    {bottomRight && (
      <div style={{
        position: 'absolute',
        right: -180, bottom: -220,
        width: 720, height: 720,
        borderRadius: '50%',
        background: 'rgba(168,213,190,0.55)',
        pointerEvents: 'none',
      }} />
    )}
    {dim && (
      <div style={{
        position: 'absolute', inset: 0,
        background: 'rgba(0,0,0,0.40)',
        pointerEvents: 'none',
      }} />
    )}
  </React.Fragment>
);

window.BgCircles = BgCircles;
