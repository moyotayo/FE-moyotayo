// FilterChip.jsx + FilterChipRow.jsx
// Two states: idle (pale blue fill) and selected (green ✓).

const FilterChip = ({ label, selected, onClick }) => (
  <button onClick={onClick} style={{
    height: 32, padding: '0 16px',
    borderRadius: 20,
    background: selected ? 'rgba(150,255,201,.6)' : '#E8F5FF',
    border: selected ? '1.5px solid rgba(30,138,82,.5)' : 0,
    color: selected ? '#0F5E36' : '#1B1B1B',
    fontFamily: 'Jua, sans-serif',
    fontSize: 16,
    lineHeight: 1,
    display: 'inline-flex', alignItems: 'center', gap: 4,
    cursor: 'pointer',
    transition: 'background 120ms',
  }}>
    {selected ? '✓ ' : ''}{label}
  </button>
);

const FilterChipRow = ({ label, options, value, onChange }) => (
  <div style={{ display: 'flex', alignItems: 'center', gap: 10, flexWrap: 'wrap' }}>
    <div style={{
      fontFamily: 'Jua, sans-serif',
      fontSize: 17,
      color: '#000',
      minWidth: 80,
    }}>{label}</div>
    {options.map(o => (
      <FilterChip
        key={o}
        label={o}
        selected={value === o}
        onClick={() => onChange(value === o ? null : o)}
      />
    ))}
  </div>
);

window.FilterChip = FilterChip;
window.FilterChipRow = FilterChipRow;
