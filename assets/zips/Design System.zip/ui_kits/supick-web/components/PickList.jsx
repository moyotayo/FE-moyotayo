// PickList.jsx — side cart panel used on the Recommend screen.

const PickListPanel = ({ items, onRemove }) => (
  <div style={{
    width: 460, height: 720,
    borderRadius: 16,
    border: '1.5px solid #2A99E5',
    background: 'rgba(255,255,255,0.6)',
    boxShadow: '0 4px 12px rgba(0,0,0,.06)',
    padding: '24px 22px',
    display: 'flex', flexDirection: 'column', gap: 14,
    position: 'relative',
  }}>
    <div style={{
      fontFamily: 'Itim, cursive',
      fontSize: 34, color: '#000',
      textAlign: 'center',
      filter: 'drop-shadow(0 2px 2px rgba(0,0,0,.15))',
    }}>PickList</div>

    <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
      {items.length === 0 && (
        <div style={{
          textAlign: 'center', fontFamily: 'Jua, sans-serif',
          fontSize: 16, color: '#757070', marginTop: 30,
        }}>비어 있어요 — 강의를 + 로 담아보세요!</div>
      )}
      {items.map(c => (
        <CourseRow
          key={c.id}
          course={c}
          compact
          right={<Stepper icon="minus" onClick={() => onRemove(c)} />}
        />
      ))}
    </div>

    {/* Basket illustration drops to the bottom of the panel when there is
        room — we hide it past 3 items to avoid overlap. */}
    {items.length <= 1 && (
      <img
        src="../../assets/picklist-basket.png"
        alt=""
        style={{
          position: 'absolute',
          right: 10, bottom: 10,
          width: 240, height: 'auto',
          opacity: 0.95,
        }}
      />
    )}
  </div>
);

window.PickListPanel = PickListPanel;
