// Mascot.jsx — bottom-right mascot anchor with optional speech bubble.
// Renders above all content; pointer-events: none so it doesn't block.

const Mascot = ({ pose = 'standing', speech, position = 'bottomRight', size = 280 }) => {
  const src = {
    standing: '../../assets/mascot-wizard-standing.png',
    studying: '../../assets/mascot-wizard-studying.png',
    portal:   '../../assets/mascot-wizard-portal.png',
  }[pose];

  const positions = {
    bottomRight: { right: 0, bottom: 0 },
    right:       { right: 0, top: 220 },
    bottomLeft:  { left: 40, bottom: 0 },
    centerRight: { right: 40, top: '50%', transform: 'translateY(-50%)' },
  };

  return (
    <div style={{
      position: 'absolute',
      ...positions[position],
      pointerEvents: 'none',
      zIndex: 10,
    }}>
      {speech && (
        <div style={{
          position: 'absolute',
          bottom: size * 0.7, right: size * 0.6,
          background: '#FFF',
          border: '1.5px solid #000',
          borderRadius: 18,
          padding: '12px 18px',
          fontFamily: 'Jua, sans-serif',
          fontSize: 17,
          color: '#000',
          lineHeight: 1.2,
          whiteSpace: 'nowrap',
          boxShadow: '0 4px 12px rgba(0,0,0,.1)',
        }}>
          {speech}
          <div style={{
            position: 'absolute', right: -10, bottom: 14,
            width: 0, height: 0,
            borderLeft: '12px solid #000',
            borderTop: '8px solid transparent',
            borderBottom: '8px solid transparent',
          }} />
          <div style={{
            position: 'absolute', right: -7, bottom: 16,
            width: 0, height: 0,
            borderLeft: '9px solid #FFF',
            borderTop: '6px solid transparent',
            borderBottom: '6px solid transparent',
          }} />
        </div>
      )}
      <img src={src} alt="" style={{
        width: size, height: 'auto',
        display: 'block',
        filter: 'drop-shadow(0 8px 20px rgba(0,0,0,0.1))',
      }} />
    </div>
  );
};

window.Mascot = Mascot;
