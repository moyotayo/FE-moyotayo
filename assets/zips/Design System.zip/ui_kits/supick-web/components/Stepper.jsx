// Stepper.jsx — circular + / − / ✓ button.

const Stepper = ({ icon = 'plus', onClick, color }) => {
  const colors = {
    plus:  '#389DE0',
    minus: '#389DE0',
    check: '#25AD67',
  };
  const c = color || colors[icon];
  const glyph = icon === 'plus' ? '+' : icon === 'minus' ? '−' : '✓';
  return (
    <button
      onClick={onClick}
      style={{
        width: 40, height: 40,
        borderRadius: '50%',
        background: c,
        color: '#FFF',
        border: 0,
        display: 'flex', alignItems: 'center', justifyContent: 'center',
        fontFamily: 'Pretendard Variable, sans-serif',
        fontWeight: 500,
        fontSize: icon === 'check' ? 18 : 22,
        cursor: 'pointer',
        lineHeight: 1,
        boxShadow: '0 2px 4px rgba(0,0,0,.15)',
      }}
    >
      {glyph}
    </button>
  );
};

window.Stepper = Stepper;
