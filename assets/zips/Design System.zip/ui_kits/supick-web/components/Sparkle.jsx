// Sparkle.jsx + category utilities — central place for the 4-point
// star icon and the seven course-category colour mappings.

window.CATEGORIES = {
  jeonseon:  { color: '#8336FF', label: '전선', english: 'Major Elective' },
  jeonhaek:  { color: '#FF0000', label: '전핵', english: 'Major Core' },
  jeonchwi:  { color: '#000000', label: '전취', english: 'Major Acquired' },
  gyoyang:   { color: '#2AD5BB', label: '교양', english: 'Liberal Arts' },
  gigyo:     { color: '#F328C7', label: '기교', english: 'Foundation' },
  junghaek:  { color: '#DC792D', label: '중핵', english: 'Core Liberal Arts' },
  sogyo:     { color: '#3CD400', label: '소교', english: 'Small Liberal Arts' },
};

// rgba helper that takes a hex like #8336FF + alpha
window.alphaHex = (hex, a) => {
  const h = hex.replace('#', '');
  const r = parseInt(h.slice(0, 2), 16);
  const g = parseInt(h.slice(2, 4), 16);
  const b = parseInt(h.slice(4, 6), 16);
  return `rgba(${r}, ${g}, ${b}, ${a})`;
};

const Sparkle = ({ color = '#1E8A52', size = 24, glow = true, glowAlpha = 0.9 }) => (
  <svg width={size} height={size * 24 / 25} viewBox="0 0 25 24" style={{
    color,
    filter: glow ? `drop-shadow(0 0 ${size * 0.4}px ${alphaHex(color, glowAlpha)})` : 'none',
    flexShrink: 0,
  }}>
    <path d="M 12.5 0 L 16.919 7.757 L 25 12 L 16.919 16.243 L 12.5 24 L 8.081 16.243 L 0 12 L 8.081 7.757 L 12.5 0 Z" fill="currentColor" />
  </svg>
);

window.Sparkle = Sparkle;
