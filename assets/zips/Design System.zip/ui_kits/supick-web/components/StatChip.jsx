// StatChip.jsx — big-number dashboard chip used at the top of Home.

const StatChip = ({ tone = 'red', value, label }) => {
  const tones = {
    red:   { border: 'rgba(255,72,72,.7)',  bg: 'rgba(255,200,200,.45)', num: '#E14545' },
    green: { border: 'rgba(60,212,0,.6)',   bg: 'rgba(200,255,200,.45)', num: '#2E9D2E' },
    cyan:  { border: 'rgba(42,213,187,.6)', bg: 'rgba(180,250,235,.45)', num: '#2A99A0' },
  };
  const t = tones[tone];
  return (
    <div style={{
      width: 200, height: 96,
      borderRadius: 15,
      border: `1.5px solid ${t.border}`,
      background: t.bg,
      boxShadow: '0 4px 4px rgba(0,0,0,0.10)',
      display: 'flex', flexDirection: 'column',
      alignItems: 'center', justifyContent: 'center',
      gap: 6,
    }}>
      <div style={{
        fontFamily: 'Pretendard Variable, sans-serif',
        fontWeight: 900,
        fontSize: 38, color: t.num, lineHeight: 1,
      }}>{value}</div>
      <div style={{
        fontFamily: 'Jua, sans-serif',
        fontSize: 14, color: '#000', lineHeight: 1,
      }}>{label}</div>
    </div>
  );
};

window.StatChip = StatChip;
