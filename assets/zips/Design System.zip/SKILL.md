---
name: supick-design
description: Use this skill to generate well-branded interfaces and assets for SuPick (수원대 강의 탐색 서비스 — a Suwon University course-exploration web app), either for production or throwaway prototypes/mocks/etc. Contains essential design guidelines, colors, type, fonts, mascot art, the seven course-category color system, and a full reusable UI kit (Welcome / Home / Recommend / Reviews / My-Page) for prototyping.
user-invocable: true
---

Read the `README.md` file within this skill first, and explore the other available files. `colors_and_type.css` carries every CSS variable plus the four web-font imports — drop it into any HTML and you're ready to design. `ui_kits/supick-web/` has a click-through React prototype you can lift screens and components from; the `components/` subfolder is the right place to look for buttons, sparkles, course rows, badges, and the timetable. The `preview/` folder is small spec cards you can read for quick reference on tokens and components.

The brand is:
- A Korean university service. Copy is Korean, written casually with a friendly samoyed-wizard mascot voice. Wordmark is always "SuPick" + green sparkle (✦).
- Soft, daylight, slightly magical. White wash backgrounds with one or two big bleed-circles (sky blue and green wedge). No dark mode. No aggressive gradients.
- Three Hangul font families: **Jua** (display, friendly), **Pretendard** (body, dense), **SUITE** (alt display). Latin uses **Inter**, with **Itim** as a script accent only for the "PickList" word.
- Seven course-category colors with matching sparkles + outline badges: 전선 (purple), 전핵 (red), 전취 (black), 교양 (teal), 기교 (magenta), 중핵 (orange), 소교 (green).
- Signature visual: the **glass-glow capsule** — a 50px pill filled with rgba(255,255,255,.10) and outlined by `0 0 20px rgba(22,86,132,.9)`. Used on top nav active items and the primary CTA.

If creating visual artifacts (slides, mocks, throwaway prototypes, etc), copy assets out of `assets/` and create static HTML files for the user to view. Import `colors_and_type.css` to get tokens and webfonts for free. The mascot PNGs in `assets/` are the source of truth — never redraw the puppy.

If working on production code, lift values from `colors_and_type.css` (or rewrite them in your stack's token format) and use the `ui_kits/supick-web/components/*.jsx` files as visual reference for component anatomy. They are illustrative, not framework-canonical.

If the user invokes this skill without any other guidance, ask them what they want to build or design, ask some questions (which surface? which mascot pose? Korean or English copy?), and act as an expert designer who outputs HTML artifacts _or_ production code, depending on the need.

**Things to avoid that come from the carpool-era of the figma file** (out of scope, do NOT use):
- Yellow capsule buttons with black text
- The 모여타요 / "택시팟" / "팟 생성" vocabulary
- Kakao login wide-button graphic
- The blue-and-yellow Frame2 button style from `/UI-Kit/components/Frame2`

The current SuPick brand uses **blue capsules with the glass-glow shadow**, not yellow buttons.
