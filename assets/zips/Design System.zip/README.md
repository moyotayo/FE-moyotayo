# SuPick Design System

> **수원대 강의 탐색 서비스** — *"Suwon University course-exploration service"*

SuPick is a student-facing web app that helps undergraduates at **University of Suwon (수원대학교)** browse, evaluate, and combine course offerings into a usable weekly timetable. The wordmark itself is "**Su**" (University of **Su**won) + "**Pick**" — finished with a four-point sparkle that doubles as the brand's magical motif. The product wraps utility (course catalog, reviews, schedule preview) in a soft, friendly fantasy aesthetic anchored by a samoyed-wizard mascot who lives across the entire experience.

The system is meant to be opened in two ways:

- **As a project tab** — every preview card visible in the "Design System" tab is a finished artifact you can drop into a slide, doc, or mockup.
- **As a Claude / Claude Code skill** — `SKILL.md` lets an agent reuse this folder verbatim when generating new SuPick-branded HTML.

---

## Product surfaces in scope

SuPick is, as of the current Figma, a **single product, web-only, desktop-first (1440×1024)**. There is no separate mobile, marketing, or admin surface yet — the desktop app is the brand. The core surfaces:

| Screen | Purpose |
|---|---|
| **Welcome** | Splash with hero wordmark, year-of-launch badge, "시작하기" pill, mascot anchor. |
| **홈 (Home)** | Personal landing — weekly sticky-note timetable on the left, vertical course list with category badges on the right, three stat chips at the top. |
| **시간표 추천 (Recommend)** | Search/filter all open courses, drop them into a side **PickList** ("픽리스트") cart, then have the **시간표 마법사 (Timetable Wizard)** auto-arrange them into a weekly grid. |
| **강의 평가 (Reviews)** | List of past courses with star ratings, hashtag tags ("#과제_적음", "#P/F"), heart-like counts. Right rail lets the user submit their own. |
| **마이페이지 (My Page)** | Profile (mascot avatar + name + 학과 + 학번 + 재학상태), credit total, pill links (문의하기 / 내 강의평 / 내 정보 / 로그아웃 / 회원 탈퇴), semester switcher, daily-affirmation footer. |

Source-of-truth Figma file (mounted as a read-only VFS in this project):

```
/Supick-Wireframe   — current hi-fi screens (the canonical look)
/Supick-User-Flow   — user-flow exploration, low-fi
/GUI-v0.1           — earlier exploration from when the project was a carpool app
/UI-Kit             — scratch/components, mostly empty
/IA                 — information architecture diagram
```

> **Note on GUI-v0.1**: the file we received started life as a Korean carpool app called **모여타요 ("Gather and Ride")** before the team pivoted to SuPick. GUI-v0.1 is the leftover from that pivot — **ignore it for SuPick visual decisions**. Yellow capsule buttons, taxi-pot copy, kakao-login graphics belong to the old product.

---

## Content fundamentals

SuPick reads like a friendly upperclassman, not a chatbot and not a marketing page. The voice is colloquial Korean with a soft fantasy garnish.

**Tone**

- **Casual & spoken**, never formal-academic. Sentences end with friendly markers (`~`, `?`, ellipsis) and avoid 합니다체.
  - "강의 평가는 SuPick에서~" — "Course reviews? Come to SuPick~"
  - "시간표 마법사 클릭클릭⚔️" — "Click click the timetable wizard ⚔️"
  - "시간표 다시 만들어줄까?" (mascot speech bubble) — "Want me to build the timetable again?"
- **The mascot speaks in first person.** The puppy wizard addresses the user directly — "이하은님 민첩한 하루되세요!" ("Have a nimble day, Lee Ha-eun!"). This is the only place Honorifics + 님 appear.
- **Specific & concrete over abstract.** Filters say "1교시 2교시 3교시…" not "Period filter". Empty states are written, not iconic.

**Casing & punctuation**

- The wordmark is always **SuPick** — never "Supick", "SUPICK", or "su pick". The "Su" (Suwon University) is set in `--blue-600` (`#1A5BA8`) and the verb "Pick" is set in `--black`; the sparkle ✦ sits to the right of the 'k', baseline-aligned, in `--green-500`. The two-tone logo separates the noun (the school) from the verb (the action) and is the canonical lockup — do not collapse both halves to a single colour.
- English in Korean copy stays Latin-cased: "AI활용ESL1", "PickList", "P/F".
- Comma-free middle-dot lists are common: "수원역4번출구·김대엽", "이수민·3학점·5영역".
- Numbers use Latin glyphs: 21학점, 4/5 (10), 17학번.

**I vs you**

- Defaults to **second person** ("당신의 Pick!"), addressed to the user.
- The mascot uses **first person** when speaking, but the surrounding UI does not.

**Emoji & special characters**

- **Emoji are used, but sparingly** and always functional, not decorative. Allowed: 📌 (pinned section header), ⚔️ (wizard CTA flourish), ☀️ 🌻 🌹 (mascot-companion flowers in the daily greeting). 3D-render style food/object emoji are *not* used — those are replaced by full photographic illustrations (basket, books).
- Unicode arrows (`>`, `<`, `→`), a checkmark `✓`, and `+`/`-` for quantity steppers are part of the visual vocabulary.
- The star/sparkle ✦ that lives next to the wordmark is drawn as an SVG, **not** a unicode glyph — it carries category color and a glow.

**Length budgets**

- Page titles: 1 line, ≤ 8 Hangul characters.
- Button labels: 2–4 Hangul characters preferred ("선택", "시작하기", "다음으로").
- Section captions: 1 line up to ~20 Hangul characters.
- The mascot speech bubble is hard-capped to ~14 characters per line.

---

## Visual foundations

**Mood.** Soft, warm, daytime, slightly magical. Think children's-book illustration meets dashboard. There are no dark-mode surfaces in the system, no sharp grid lines, no aggressive gradients. The background is always one of two: a near-white wash or a pale sky-blue tinted by a giant out-of-frame circle.

**Colors.**

- **Primary** is SuPick blue `#2A99E5` (`--blue-500`) for borders, headers, primary buttons, and "selected" states. Its deeper sibling `#1A5BA8` (`--blue-600`) is reserved for the launch-date pill and the tagline.
- **Brand sparkle** is `#1E8A52` green — the second half of the wordmark and the dominant accent that says "this is SuPick, not just a blue product."
- **Background** is white. The page acquires colour from one or two huge half-circles in `--blue-200` (top-left) and a green wedge (bottom-right) that bleed off-canvas. Inner cards layer a `--grad-card-blue` (white → mid-blue) gradient.
- **Course categories** each own a saturated colour (purple/red/teal/magenta/orange/green/black). These appear three times per course row: as a sparkle icon, as a thin outline+text on the badge pill, and as a tinted glow halo around the sparkle. **Never use a category color outside its category** — purple does not mean "selected", it means "전선".

**Typography.** Three Korean families, each with one job.

- **Jua** — the friendly, brush-rounded Hangul display face. Page titles, button labels, chip text, mascot speech. This is what gives SuPick its "soft" feel; if you remove it the brand feels generic.
- **Pretendard ExtraBold/Bold** — course titles and dense sub-heads. Pretendard is the "serious" face that keeps the timetable readable when packed with text.
- **SUITE Variable** — a third Hangul face that appears on a handful of older display moments. Treat as a fallback; prefer Jua when authoring new work.
- **Inter** (Latin) — numerals, English course codes, professor names rendered in Latin, "SuPick" wordmark glyphs.
- **Itim** (Latin script) — only used for the playful "PickList" sub-header. Do not extend it elsewhere.

**Backgrounds & imagery.**

- Pages use a **white wash** with **one or two giant, low-opacity circles** ( `--blue-200`, ~210–400px diameter at desktop scale) bleeding off the canvas corners. This is the brand's signature background motif.
- A second, smaller green circle hugs the bottom-right corner behind the mascot.
- Photographic 3D-render illustrations of the mascot (samoyed in a hooded wizard cape) anchor most pages. They are placed at the right edge, mid-page, never centered.
- One additional product render — a baby-blue **shopping basket with a checklist** — is used to dramatize the "PickList" (cart-of-courses) concept.

**Cards.**

- Always **white or white→blue gradient**, never tinted or dark.
- Border: `1px solid var(--blue-500)` for hi-emphasis cards (profile, stat block), `1px solid var(--black)` for the timetable wrapper, **no border** for the simple modal-style review card.
- Radius: **10px** (everything practical) or **14px** (the big calendar card).
- Shadow: `--shadow-drop` for inset chips, `--shadow-drop-big` for the calendar, `--shadow-glow-blue` for stat-chip outlines that need to "lift".

**Buttons, chips, and the "glass capsule".**

- Three button shapes. **Pill (r-pill)** for primary CTA ("시작하기"), filter chips, and nav items. **Rounded rectangle (r-sm)** for inline actions ("문의하기", "내 정보"). **Circular (r-full)** for steppers ( `+` / `-` / `✓`) and floating add-to-list buttons.
- The signature "**glass capsule**" — a 50px-tall pill filled with `rgba(255,255,255,0.10)`, outlined by `--shadow-glow-glass` (deep blue outer glow) — wraps the top nav and is the only place we use translucent fills.
- Filter chips on the recommend page have two states only: **pale blue fill** (unselected) and **green-tinted fill with ✓** (selected). Disabled does not exist visually.

**Glows, shadows, transparency, blur.**

- **Outer glow** is THE SuPick effect. Sparkles, primary chips, the launch-date pill all bloom outward with `box-shadow: 0 0 20px <color-90%>`.
- **Soft drop shadows** (4px y, 4px blur, 25% black) live on every card and chip.
- **Photo drop shadows** (12px y, 40px blur, 50% black) lift the big calendar card off the wash.
- **Blur** is rare — we avoid backdrop-filter entirely. The "glass" look is built from low-alpha fill + glow, not blur.

**Layout rules.**

- Desktop canvas is **1440×1024**. Pages use a generous outer margin (~70–110px) and rely on two anchored zones: left column ~ 760px, right column ~ 460–480px.
- The **top nav is always pinned** to top: 30–55px from page top, centered horizontally, with the SuPick logo at left and "마이페이지" at right.
- The mascot lives in the **bottom-right or right-edge mid-page**, partially clipped by the page edge. Never centered, never floating in white space.

**Motion.**

The current Figma doesn't specify animation. The recommended posture matches the brand:

- **Ease-out, ~200ms** for hovers (color shift on chips, scale 1.02 on the primary pill).
- **Spring-y** for adding/removing a course in the PickList (scale 0.96 → 1.04 → 1).
- **No looping ambient motion** — sparkles do not animate, the mascot does not bob. The product is calm.

**Hover & press states.**

- **Hover** on chips: fill goes from `--blue-100` → white, border stays.
- **Hover** on primary pill: glow intensity bumps from `--shadow-glow-glass` to the same with 1.5× spread.
- **Press** on chips and pills: 96% scale, no color change.
- Disabled state is signalled by 40% opacity, not a different colour.

**Corner radii summary.** 10 / 14 / 15 / 20 / 100. No 4, no 6, no 8. Stay on the scale.

---

## Iconography

SuPick **does not use a unified icon font**. It mixes three sources:

1. **A single in-house glyph: the 4-point sparkle ✦.** This is drawn as a tinted SVG (`<path d="M 12.5 0 L … Z" />`) wrapped in a category-color glow. Reuse `assets/sparkle.svg` and pass a `--sparkle-color` custom property. It appears next to the wordmark, beside every course-list row, and on the welcome page beside the launch badge. The sparkle is the closest thing SuPick has to a system icon, and you should reach for it before any other icon.

2. **Iconify presets** — the Figma references `fluent-emoji-flat:sun-with-face`, `noto-v1:sunflower`, `emojione:rose`, `mdi:heart`. These appear only on the My Page footer ("이하은님 민첩한 하루되세요!" + ☀️🌻🌹) and on the review heart counter. For new screens, prefer the actual Iconify CDN URLs (`https://api.iconify.design/<set>/<name>.svg`) over redrawing them.

3. **Photographic 3D renders** — the mascot, the shopping basket, the book stack. These are *not* icons; they are full art. Treat them as illustrations, not as repeatable UI elements.

**Things SuPick does not do:**

- No Material / SF Symbols / Heroicons sprite.
- No emoji used as bullet markers or list dingbats (the 📌 on "📌 2026학년도 1학기 시간표" is a one-off).
- No filled vs outline icon dichotomy — there are too few icons for that to matter.

Assets in this folder:

```
assets/
  mascot-wizard-standing.png    primary mascot, used on Welcome + every dashboard
  mascot-wizard-studying.png    lying-down + glasses pose, for "강의 평가" sections
  mascot-wizard-portal.png      mascot facing a magical portal, for "마법사" CTAs
  picklist-basket.png           3D blue shopping basket with checklist, for cart
  sparkle.svg                   the 4-point star — pass --sparkle-color
  logo-supick.svg               wordmark + sparkle lockup
```

> **Substitution flag**: the figma also references emoji icons via `fluent-emoji-flat:*` and `emojione:*` icon-set names. We did not copy those binary PNGs from the Figma; live SVGs are loaded from the public Iconify CDN at render time. If you need those baked into a static export, swap to `https://api.iconify.design/<set>/<name>.svg` and save the response into `assets/`.

---

## Fonts

| Family | Source | Notes |
|---|---|---|
| **Jua** | Google Fonts | Primary display Hangul. Single weight (400). |
| **Pretendard** | jsDelivr CDN (orioncactus) | Variable + static. We import the static stack from `pretendard@v1.3.9`. |
| **SUITE** | jsDelivr CDN (sun-typeface) | Variable. Used in a handful of older display titles. |
| **Inter** | Google Fonts | 400 / 500 / 700 / 800 / 900. |
| **Itim** | Google Fonts | Only for "PickList" sub-headings. |

All font loading is handled by `colors_and_type.css` — just import that file and you're done. No local `.woff2` files in `fonts/` because every face is reachable from a public CDN; if you need to ship truly offline, this is where you would mirror them.

> **No substitutions were required** — every face the figma uses is available on a free CDN.

---

## Index

```
README.md                this file
SKILL.md                 agent-readable skill manifest (Claude Code compatible)
colors_and_type.css      every CSS variable + font import
assets/                  mascot art + sparkle SVG + logo lockup
preview/                 small HTML cards that populate the "Design System" tab
ui_kits/
  supick-web/            the SuPick web product as JSX components + a live click-thru demo
    README.md
    index.html
    components/*.jsx
```

`ui_kits/supick-web/index.html` is the place to start if you want to see the product running. It boots the welcome page and lets you click through home, recommend, reviews, and my-page using only React state.

---

## Caveats & open questions

- **No real codebase was provided** — every component below is reconstructed from the Figma pseudocode and screenshots. Implementations are cosmetic, not production.
- **Animation behavior is invented** — the Figma doesn't define motion, so anything in `colors_and_type.css` under "Motion" is a recommendation, not a brand fact.
- **The earlier carpool product (모여타요)** lingers in `/GUI-v0.1` of the Figma. Treat anything yellow-capsule-button-shaped from there as out of scope.
- **The mascot has more poses** than the four we copied (welcome-stand, studying, portal, basket). If you need a new pose, ask the brand owners — do not redraw it.
