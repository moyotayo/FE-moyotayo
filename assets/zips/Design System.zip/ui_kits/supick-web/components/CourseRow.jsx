// CourseRow.jsx — sparkle + title + meta + category badge.
// `right` slot optionally renders a + / − / ✓ button at the far right.

const CourseRow = ({ course, right, onClick, compact = false }) => {
  const cat = CATEGORIES[course.category];
  return (
    <div
      onClick={onClick}
      style={{
        position: 'relative',
        height: compact ? 64 : 80,
        borderRadius: 16,
        background: 'rgba(255,255,255,0.55)',
        boxShadow: '0 2px 6px rgba(0,0,0,.05), inset 0 0 0 1px rgba(0,0,0,0.08)',
        display: 'flex',
        alignItems: 'center',
        padding: '0 22px',
        gap: 16,
        cursor: onClick ? 'pointer' : 'default',
      }}
    >
      <Sparkle color={cat.color} size={26} />
      <div style={{ flex: 1, display: 'flex', flexDirection: 'column', gap: 5 }}>
        <div style={{
          fontFamily: 'Pretendard Variable, Pretendard, sans-serif',
          fontWeight: 700,
          fontSize: 18,
          color: '#000',
          lineHeight: 1,
        }}>
          {course.title}
        </div>
        <div style={{
          fontFamily: 'Pretendard Variable, sans-serif',
          fontSize: 15,
          color: '#4B4B4B',
          lineHeight: 1,
        }}>
          {course.location ? `${course.location} · ` : ''}{course.professor}
        </div>
      </div>
      <CategoryBadge category={course.category} />
      {right ? <div style={{ marginLeft: 6 }}>{right}</div> : null}
    </div>
  );
};

window.CourseRow = CourseRow;
