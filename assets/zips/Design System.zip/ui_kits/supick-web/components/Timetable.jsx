// Timetable.jsx — the weekly calendar card with sticky-note course blocks.
// Renders a fixed grid (월~금 × 9:30~18:30) and positions each course as
// an absolutely-placed coloured note with a pin in its category colour.

const DAYS = ['월','화','수','목','금'];
const HOURS = ['9:30','10:30','11:30','12:30','13:30','14:30','15:30','16:30','17:30','18:30'];

const NOTE_FILLS = {
  jeonseon: '#C5B6FF',
  jeonhaek: '#F3A8C7',
  jeonchwi: '#D9D9D9',
  gyoyang:  '#A8E5D5',
  gigyo:    '#F3A8E5',
  junghaek: '#FFB37A',
  sogyo:    '#B0F09A',
};

// pre-assigned colors so the sample timetable looks like the figma
const NOTE_OVERRIDES = {
  'mw':  '#FFE262',  // yellow
  'ca':  '#A8D5BE',  // green
  'net': '#7FDBFF',  // cyan
  'sem': '#C5DFF0',  // blue
  'esl': '#F3A8C7',  // pink
  'thn': '#A8D5BE',  // green
  'lif': '#3CD400',  // green dot for sogyo
  'web': '#FFB37A',  // orange
};

const Timetable = ({ courses, title = '📌 2026학년도 1학기 시간표', height = 720 }) => {
  // grid geometry
  const padTop = 100;
  const padLeft = 70;
  const dayW = 130;
  const hourH = 56;

  const toY = (time) => {
    const [h, m] = time.split(':').map(Number);
    const mins = (h - 9) * 60 + (m - 30);   // 9:30 == 0
    return padTop + (mins / 60) * hourH;
  };

  return (
    <div style={{
      position: 'relative',
      width: 760, height,
      borderRadius: 14,
      overflow: 'hidden',
      border: '1px solid #000',
      background: 'linear-gradient(180deg, #F9F9F9 0%, #6CC0FA 100%)',
      boxShadow: '0 12px 40px rgba(0,0,0,0.50)',
    }}>
      {/* Title pill */}
      <div style={{
        position: 'absolute', left: '50%', top: 40,
        transform: 'translateX(-50%)',
        height: 32, padding: '0 22px',
        borderRadius: 8,
        background: '#5BAFE5',
        color: '#FFF',
        fontFamily: 'Pretendard, sans-serif',
        fontSize: 16, fontWeight: 500,
        display: 'flex', alignItems: 'center',
      }}>{title}</div>

      {/* Day headers */}
      {DAYS.map((d, i) => (
        <div key={d} style={{
          position: 'absolute',
          left: padLeft + i * dayW + 20, top: padTop - 36,
          width: dayW - 40, height: 28,
          borderRadius: 100,
          background: '#9BC6E8',
          color: '#FFF',
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          fontFamily: 'Pretendard, sans-serif',
          fontWeight: 700, fontSize: 15,
        }}>{d}</div>
      ))}

      {/* Hour labels */}
      {HOURS.map((h, i) => (
        <div key={h} style={{
          position: 'absolute',
          left: 18, top: padTop + i * hourH - 8,
          fontFamily: 'Pretendard, sans-serif',
          fontWeight: 700, fontSize: 14,
          color: '#1A5BA8',
        }}>{h}</div>
      ))}

      {/* Horizontal grid lines */}
      {HOURS.map((h, i) => (
        i === 0 ? null :
        <div key={'l'+h} style={{
          position: 'absolute',
          left: padLeft, right: 14,
          top: padTop + i * hourH,
          height: 1,
          background: 'rgba(255,255,255,0.55)',
        }} />
      ))}

      {/* Course sticky notes */}
      {courses.map(c => {
        const dayIdx = DAYS.indexOf(c.day);
        if (dayIdx < 0) return null;
        const y1 = toY(c.start), y2 = toY(c.end);
        const noteColor = NOTE_OVERRIDES[c.id] || NOTE_FILLS[c.category] || '#FFE262';
        const pinColor  = CATEGORIES[c.category].color;
        return (
          <div key={c.id} style={{
            position: 'absolute',
            left: padLeft + dayIdx * dayW + 8,
            top: y1,
            width: dayW - 16,
            height: y2 - y1,
            background: noteColor,
            borderRadius: 6,
            boxShadow: '2px 4px 12px rgba(0,0,0,0.28)',
          }}>
            <div style={{
              position: 'absolute', top: -6, left: '50%',
              transform: 'translateX(-50%)',
              width: 12, height: 12, borderRadius: '50%',
              background: pinColor,
              boxShadow: '0 1px 2px rgba(0,0,0,.4)',
            }} />
          </div>
        );
      })}
    </div>
  );
};

window.Timetable = Timetable;
