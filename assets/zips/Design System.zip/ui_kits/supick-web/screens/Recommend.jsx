// Recommend.jsx — search + filters + course results + PickList side panel.

const Recommend = ({ allCourses, picklist, onPickListChange }) => {
  const [query, setQuery] = React.useState('');
  const [showFilters, setShowFilters] = React.useState(true);
  const [areaFilter, setAreaFilter] = React.useState('5영역');
  const [periodFilter, setPeriodFilter] = React.useState('6교시');
  const [majorFilter, setMajorFilter] = React.useState('교양');

  const add = (c) => {
    if (!picklist.find(x => x.id === c.id)) onPickListChange([...picklist, c]);
  };
  const remove = (c) => onPickListChange(picklist.filter(x => x.id !== c.id));

  const visible = allCourses.filter(c =>
    !query || c.title.includes(query) || c.professor.includes(query)
  );

  return (
    <div style={{ position: 'absolute', inset: 0, background: '#FFF' }}>
      <BgCircles />

      <div style={{ position: 'absolute', top: 130, left: 70, right: 70, display: 'flex', gap: 32 }}>
        {/* Left — search + filter + results */}
        <div style={{ flex: 1, display: 'flex', flexDirection: 'column', gap: 18 }}>
          <div style={{
            fontFamily: 'Jua, sans-serif',
            fontSize: 38, color: '#000', lineHeight: 1,
          }}>시간표 추천</div>

          <SearchInput
            value={query}
            onChange={setQuery}
            withFilter
            onFilter={() => setShowFilters(v => !v)}
            filterActive={showFilters}
          />

          {showFilters && (
            <div style={{
              padding: '22px 24px',
              border: '1.5px solid #2A99E5',
              borderRadius: 18,
              background: 'rgba(255,255,255,.6)',
              display: 'flex', flexDirection: 'column', gap: 14,
            }}>
              <FilterChipRow
                label="영역별"
                options={['1영역','2영역','3영역','4영역','5영역','6영역']}
                value={areaFilter} onChange={setAreaFilter}
              />
              <FilterChipRow
                label="시간별"
                options={['1교시','2교시','3교시','4교시','5교시','6교시','7교시','8교시','9교시']}
                value={periodFilter} onChange={setPeriodFilter}
              />
              <FilterChipRow
                label="전공/교양"
                options={['전공','교양']}
                value={majorFilter} onChange={setMajorFilter}
              />
            </div>
          )}

          <div style={{
            padding: '14px 18px',
            border: '1.5px solid #2A99E5',
            borderRadius: 18,
            background: 'rgba(255,255,255,.55)',
            display: 'flex', flexDirection: 'column', gap: 10,
            maxHeight: 380, overflowY: 'auto',
          }}>
            {visible.map(c => {
              const inList = picklist.find(x => x.id === c.id);
              return (
                <CourseRow
                  key={c.id}
                  course={c}
                  right={inList
                    ? <Stepper icon="check" />
                    : <Stepper icon="plus" onClick={() => add(c)} />}
                />
              );
            })}
          </div>
        </div>

        {/* Right — PickList */}
        <PickListPanel items={picklist} onRemove={remove} />
      </div>

      <Mascot
        pose="portal" size={300}
        position="bottomRight"
        speech={picklist.length >= 2 ? '시간표마법사 클릭클릭⚔️' : null}
      />
    </div>
  );
};

window.Recommend = Recommend;
