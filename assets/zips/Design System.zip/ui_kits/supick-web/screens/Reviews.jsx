// Reviews.jsx — list of reviews + composer rail.

const Reviews = ({ reviews, courses }) => {
  const [query, setQuery] = React.useState('');
  return (
    <div style={{ position: 'absolute', inset: 0, background: '#FFF' }}>
      <BgCircles />

      <div style={{
        position: 'absolute', top: 130, left: 70, right: 70,
        display: 'flex', gap: 32,
      }}>
        {/* Left — review list */}
        <div style={{ flex: 1, display: 'flex', flexDirection: 'column', gap: 22 }}>
          <div style={{
            display: 'inline-block', alignSelf: 'flex-start',
            background: '#FFF',
            border: '2px solid #2A99E5',
            borderRadius: '50%/55%',
            padding: '14px 36px',
            fontFamily: 'Jua, sans-serif',
            fontSize: 32, color: '#000',
            boxShadow: '0 4px 4px rgba(0,0,0,.1)',
          }}>강의 평가는 SuPick에서~</div>

          <SearchInput value={query} onChange={setQuery} />

          <div style={{
            borderRadius: 12,
            background: 'rgba(255,255,255,.7)',
            border: '1.5px solid #2A99E5',
            boxShadow: '0 4px 8px rgba(0,0,0,.04)',
            padding: '4px 6px',
            display: 'flex', flexDirection: 'column',
          }}>
            {reviews.map(r => <ReviewRow key={r.id} review={r} />)}
          </div>
        </div>

        {/* Right — composer */}
        <div style={{
          width: 380,
          background: 'linear-gradient(180deg, #FFFFFF 0%, #6CC0FA 100%)',
          borderRadius: 18,
          border: '1.5px solid #2A99E5',
          padding: 22,
          display: 'flex', flexDirection: 'column', gap: 16,
          boxShadow: '0 4px 12px rgba(0,0,0,.06)',
        }}>
          <div style={{
            fontFamily: 'Pretendard Variable, sans-serif',
            fontWeight: 800, fontSize: 22, color: '#000', lineHeight: 1.2,
          }}>수강 과목 평가하기</div>

          <div style={{
            height: 100,
            borderRadius: 12,
            background: '#FFF',
            border: '1px solid #C5DFF0',
          }} />

          <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
            {courses.filter(c => ['thn','lif'].includes(c.id)).map(c =>
              <CourseRow key={c.id} course={c} compact />
            )}
          </div>

          <div style={{ marginTop: 'auto', display: 'flex', justifyContent: 'flex-end' }}>
            <Button variant="rect">평가 작성하기</Button>
          </div>
        </div>
      </div>

      <Mascot pose="studying" size={300} position="bottomLeft" />
    </div>
  );
};

window.Reviews = Reviews;
